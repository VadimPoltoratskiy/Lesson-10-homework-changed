package pack1;

import java.util.Scanner;

public class Database {

	private Book[] data = new Book[20];
	private Category[] dataCat = new Category[20];
	int nextIndex;
	int nextIndexCat;

	/*public Database() {
		nextIndex = 0;
		nextIndexCat = 0;
	}

	public Database(Book[] data, Category[] dataCat, int nextIndex, int nextIndexCat) {
		super();
		this.data = data;
		this.dataCat = dataCat;
		this.nextIndex = nextIndex;
		this.nextIndexCat = nextIndexCat;
	}*/

	/*public Book[] getData() {
		return data;
	}

	public void setData(Book[] data) {
		this.data = data;
	}

	public Category[] getDataCat() {
		return dataCat;
	}

	public void setDataCat(Category[] dataCat) {
		this.dataCat = dataCat;
	}

	public int getNextIndex() {
		return nextIndex;
	}

	public void setNextIndex(int nextIndex) {
		this.nextIndex = nextIndex;
	}

	public int getNextIndexCat() {
		return nextIndexCat;
	}

	public void setNextIndexCat(int nextIndexCat) {
		this.nextIndexCat = nextIndexCat;
	}
*/
	
	public void addBook(Book b) {
		data[nextIndex] = b;
		nextIndex++;
	}
	
	public void editBook(int index) {
		int idValue;
		String titleValue;
		String authorValue;
		String discriptionValue;
		int catIdValue;
		int statusValue;
		
		System.out.println("Enter idValue ");
		Scanner sc = new Scanner(System.in);
		idValue = sc.nextInt();
		sc.close();
		
		System.out.println("Enter titleValue ");
		Scanner sc1 = new Scanner(System.in);
		titleValue = sc1.toString();
		sc1.close();
		
		System.out.println("Enter authorValue ");
		Scanner sc2 = new Scanner(System.in);
		authorValue = sc2.toString();
		sc2.close();
		
		System.out.println("Enter discriptionValue ");
		Scanner sc3 = new Scanner(System.in);
		discriptionValue = sc3.toString();
		sc3.close();
		
		System.out.println("Enter catIdValue ");
		Scanner sc4 = new Scanner(System.in);
		catIdValue = sc4.nextInt();
		sc4.close();
		
		System.out.println("Enter statusValue ");
		Scanner sc5 = new Scanner(System.in);
		statusValue = sc5.nextInt();
		sc5.close();
	}
	
	public void deleteBook(int index) {
		int statusValue;

		statusValue = 0;
		data[index].setStatus(statusValue);
	}
	
}
