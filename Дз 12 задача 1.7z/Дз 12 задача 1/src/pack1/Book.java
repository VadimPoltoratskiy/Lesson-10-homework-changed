package pack1;

public class Book {
	private int id;
	private String title;
	private String author;
	private String discription;
	private int catId;
	private int status;
	
	public Book() {
		id = 0;
		title = "Unknown";
		author = "Unknown";
		discription = "Unknown";
		catId = 0;
		status = 0;
	}
	
	public Book(int id, String title, String author, String discription, int catID, int status) {
		this.id = id;
		this.title = title;
		this.author = author;
		this.discription = discription;
		this.catId = catId;
		this.status = status;
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDiscription() {
		return discription;
	}

	public void setDiscription(String discription) {
		this.discription = discription;
	}

	public int getCatId() {
		return catId;
	}

	public void setCatId(int catId) {
		this.catId = catId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	

}
